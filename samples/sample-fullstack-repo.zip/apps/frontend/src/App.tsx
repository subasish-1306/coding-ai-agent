import React from 'react';
export const App = () => <h1>E-Commerce Storefront</h1>;
