# Sample E-Commerce Monorepo

Full-stack e-commerce project with React frontend and FastAPI backend.